﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        splitContainer1 = New SplitContainer()
        treeView1 = New TreeView()
        contextMenuStrip1 = New ContextMenuStrip(components)
        selectFileToolStripMenuItem = New ToolStripMenuItem()
        selectFolderToolStripMenuItem = New ToolStripMenuItem()
        panel1 = New Panel()
        btnCombine = New Button()
        lblTokenCount = New Label()
        cmbProjectType = New ComboBox()
        lblProjectType = New Label()
        cmbTemplate = New ComboBox()
        lblTemplate = New Label()
        btnRefresh = New Button()
        btnLoadTemplate = New Button()
        btnCopyTemplate = New Button()
        btnUpdateTemplate = New Button()
        btnSaveTemplate = New Button()
        txtTemplateName = New TextBox()
        lblTemplateName = New Label()
        txtProjectTitle = New TextBox()
        lblProjectTitle = New Label()
        txtProjectInstructions = New TextBox()
        lblProjectInstructions = New Label()
        txtOtherInstructions = New TextBox()
        lblOtherInstructions = New Label()
        menuStrip1 = New MenuStrip()
        fileToolStripMenuItem = New ToolStripMenuItem()
        exitToolStripMenuItem = New ToolStripMenuItem()
        settingsToolStripMenuItem = New ToolStripMenuItem()
        statusStrip1 = New StatusStrip()
        toolStripStatusLabel1 = New ToolStripStatusLabel()
        folderBrowserDialog1 = New FolderBrowserDialog()
        openFileDialog1 = New OpenFileDialog()
        CType(splitContainer1, ComponentModel.ISupportInitialize).BeginInit()
        splitContainer1.Panel1.SuspendLayout()
        splitContainer1.Panel2.SuspendLayout()
        splitContainer1.SuspendLayout()
        contextMenuStrip1.SuspendLayout()
        panel1.SuspendLayout()
        menuStrip1.SuspendLayout()
        statusStrip1.SuspendLayout()
        SuspendLayout()
        ' 
        ' splitContainer1
        ' 
        splitContainer1.Dock = DockStyle.Fill
        splitContainer1.Location = New Point(0, 24)
        splitContainer1.Name = "splitContainer1"
        ' 
        ' splitContainer1.Panel1
        ' 
        splitContainer1.Panel1.Controls.Add(treeView1)
        ' 
        ' splitContainer1.Panel2
        ' 
        splitContainer1.Panel2.Controls.Add(panel1)
        splitContainer1.Size = New Size(1050, 614)
        splitContainer1.SplitterDistance = 350
        splitContainer1.TabIndex = 0
        ' 
        ' treeView1
        ' 
        treeView1.CheckBoxes = True
        treeView1.ContextMenuStrip = contextMenuStrip1
        treeView1.Dock = DockStyle.Fill
        treeView1.Location = New Point(0, 0)
        treeView1.Name = "treeView1"
        treeView1.Size = New Size(350, 614)
        treeView1.TabIndex = 0
        ' 
        ' contextMenuStrip1
        ' 
        contextMenuStrip1.Items.AddRange(New ToolStripItem() {selectFileToolStripMenuItem, selectFolderToolStripMenuItem})
        contextMenuStrip1.Name = "contextMenuStrip1"
        contextMenuStrip1.Size = New Size(142, 48)
        ' 
        ' selectFileToolStripMenuItem
        ' 
        selectFileToolStripMenuItem.Name = "selectFileToolStripMenuItem"
        selectFileToolStripMenuItem.Size = New Size(141, 22)
        selectFileToolStripMenuItem.Text = "Select File"
        ' 
        ' selectFolderToolStripMenuItem
        ' 
        selectFolderToolStripMenuItem.Name = "selectFolderToolStripMenuItem"
        selectFolderToolStripMenuItem.Size = New Size(141, 22)
        selectFolderToolStripMenuItem.Text = "Select Folder"
        ' 
        ' panel1
        ' 
        panel1.Controls.Add(btnCombine)
        panel1.Controls.Add(lblTokenCount)
        panel1.Controls.Add(cmbProjectType)
        panel1.Controls.Add(lblProjectType)
        panel1.Controls.Add(cmbTemplate)
        panel1.Controls.Add(lblTemplate)
        panel1.Controls.Add(btnRefresh)
        panel1.Controls.Add(btnLoadTemplate)
        panel1.Controls.Add(btnCopyTemplate)
        panel1.Controls.Add(btnUpdateTemplate)
        panel1.Controls.Add(btnSaveTemplate)
        panel1.Controls.Add(txtTemplateName)
        panel1.Controls.Add(lblTemplateName)
        panel1.Controls.Add(txtProjectTitle)
        panel1.Controls.Add(lblProjectTitle)
        panel1.Controls.Add(txtProjectInstructions)
        panel1.Controls.Add(lblProjectInstructions)
        panel1.Controls.Add(txtOtherInstructions)
        panel1.Controls.Add(lblOtherInstructions)
        panel1.Dock = DockStyle.Fill
        panel1.Location = New Point(0, 0)
        panel1.Name = "panel1"
        panel1.Size = New Size(696, 614)
        panel1.TabIndex = 0
        ' 
        ' btnCombine
        ' 
        btnCombine.Font = New Font("Microsoft Sans Serif", 12F, FontStyle.Bold)
        btnCombine.Location = New Point(18, 469)
        btnCombine.Name = "btnCombine"
        btnCombine.Size = New Size(175, 47)
        btnCombine.TabIndex = 9
        btnCombine.Text = "Combine Files"
        btnCombine.UseVisualStyleBackColor = True
        ' 
        ' lblTokenCount
        ' 
        lblTokenCount.AutoSize = True
        lblTokenCount.Font = New Font("Microsoft Sans Serif", 10F)
        lblTokenCount.Location = New Point(18, 534)
        lblTokenCount.Name = "lblTokenCount"
        lblTokenCount.Size = New Size(105, 17)
        lblTokenCount.TabIndex = 8
        lblTokenCount.Text = "Token Count: 0"
        ' 
        ' cmbProjectType
        ' 
        cmbProjectType.DropDownStyle = ComboBoxStyle.DropDownList
        cmbProjectType.FormattingEnabled = True
        cmbProjectType.Location = New Point(131, 169)
        cmbProjectType.Name = "cmbProjectType"
        cmbProjectType.Size = New Size(263, 23)
        cmbProjectType.TabIndex = 7
        ' 
        ' lblProjectType
        ' 
        lblProjectType.AutoSize = True
        lblProjectType.Location = New Point(18, 172)
        lblProjectType.Name = "lblProjectType"
        lblProjectType.Size = New Size(74, 15)
        lblProjectType.TabIndex = 6
        lblProjectType.Text = "Project Type:"
        ' 
        ' cmbTemplate
        ' 
        cmbTemplate.DropDownStyle = ComboBoxStyle.DropDownList
        cmbTemplate.FormattingEnabled = True
        cmbTemplate.Location = New Point(131, 122)
        cmbTemplate.Name = "cmbTemplate"
        cmbTemplate.Size = New Size(193, 23)
        cmbTemplate.TabIndex = 5
        ' 
        ' lblTemplate
        ' 
        lblTemplate.AutoSize = True
        lblTemplate.Location = New Point(18, 125)
        lblTemplate.Name = "lblTemplate"
        lblTemplate.Size = New Size(58, 15)
        lblTemplate.TabIndex = 4
        lblTemplate.Text = "Template:"
        ' 
        ' btnRefresh
        ' 
        btnRefresh.Location = New Point(494, 427)
        btnRefresh.Name = "btnRefresh"
        btnRefresh.Size = New Size(66, 24)
        btnRefresh.TabIndex = 10
        btnRefresh.Text = "Refresh"
        btnRefresh.UseVisualStyleBackColor = True
        ' 
        ' btnLoadTemplate
        ' 
        btnLoadTemplate.Location = New Point(328, 121)
        btnLoadTemplate.Name = "btnLoadTemplate"
        btnLoadTemplate.Size = New Size(66, 24)
        btnLoadTemplate.TabIndex = 10
        btnLoadTemplate.Text = "Load"
        btnLoadTemplate.UseVisualStyleBackColor = True
        ' 
        ' btnCopyTemplate
        ' 
        btnCopyTemplate.Location = New Point(398, 121)
        btnCopyTemplate.Name = "btnCopyTemplate"
        btnCopyTemplate.Size = New Size(66, 24)
        btnCopyTemplate.TabIndex = 3
        btnCopyTemplate.Text = "Copy"
        btnCopyTemplate.UseVisualStyleBackColor = True
        ' 
        ' btnUpdateTemplate
        ' 
        btnUpdateTemplate.Location = New Point(470, 122)
        btnUpdateTemplate.Name = "btnUpdateTemplate"
        btnUpdateTemplate.Size = New Size(66, 22)
        btnUpdateTemplate.TabIndex = 11
        btnUpdateTemplate.Text = "Update"
        ' 
        ' btnSaveTemplate
        ' 
        btnSaveTemplate.Location = New Point(254, 75)
        btnSaveTemplate.Name = "btnSaveTemplate"
        btnSaveTemplate.Size = New Size(66, 28)
        btnSaveTemplate.TabIndex = 2
        btnSaveTemplate.Text = "Save"
        btnSaveTemplate.UseVisualStyleBackColor = True
        ' 
        ' txtTemplateName
        ' 
        txtTemplateName.Location = New Point(131, 28)
        txtTemplateName.Name = "txtTemplateName"
        txtTemplateName.Size = New Size(263, 23)
        txtTemplateName.TabIndex = 1
        ' 
        ' lblTemplateName
        ' 
        lblTemplateName.AutoSize = True
        lblTemplateName.Location = New Point(18, 31)
        lblTemplateName.Name = "lblTemplateName"
        lblTemplateName.Size = New Size(93, 15)
        lblTemplateName.TabIndex = 0
        lblTemplateName.Text = "Template Name:"
        ' 
        ' txtProjectTitle
        ' 
        txtProjectTitle.Location = New Point(131, 206)
        txtProjectTitle.Name = "txtProjectTitle"
        txtProjectTitle.Size = New Size(350, 23)
        txtProjectTitle.TabIndex = 12
        ' 
        ' lblProjectTitle
        ' 
        lblProjectTitle.AutoSize = True
        lblProjectTitle.Location = New Point(18, 209)
        lblProjectTitle.Name = "lblProjectTitle"
        lblProjectTitle.Size = New Size(72, 15)
        lblProjectTitle.TabIndex = 11
        lblProjectTitle.Text = "Project Title:"
        ' 
        ' txtProjectInstructions
        ' 
        txtProjectInstructions.Location = New Point(131, 244)
        txtProjectInstructions.Multiline = True
        txtProjectInstructions.Name = "txtProjectInstructions"
        txtProjectInstructions.ScrollBars = ScrollBars.Vertical
        txtProjectInstructions.Size = New Size(350, 75)
        txtProjectInstructions.TabIndex = 14
        ' 
        ' lblProjectInstructions
        ' 
        lblProjectInstructions.AutoSize = True
        lblProjectInstructions.Location = New Point(18, 247)
        lblProjectInstructions.Name = "lblProjectInstructions"
        lblProjectInstructions.Size = New Size(112, 15)
        lblProjectInstructions.TabIndex = 13
        lblProjectInstructions.Text = "Project Instructions:"
        ' 
        ' txtOtherInstructions
        ' 
        txtOtherInstructions.Location = New Point(131, 338)
        txtOtherInstructions.Multiline = True
        txtOtherInstructions.Name = "txtOtherInstructions"
        txtOtherInstructions.ScrollBars = ScrollBars.Vertical
        txtOtherInstructions.Size = New Size(350, 75)
        txtOtherInstructions.TabIndex = 16
        ' 
        ' lblOtherInstructions
        ' 
        lblOtherInstructions.AutoSize = True
        lblOtherInstructions.Location = New Point(18, 340)
        lblOtherInstructions.Name = "lblOtherInstructions"
        lblOtherInstructions.Size = New Size(105, 15)
        lblOtherInstructions.TabIndex = 15
        lblOtherInstructions.Text = "Other Instructions:"
        ' 
        ' menuStrip1
        ' 
        menuStrip1.Items.AddRange(New ToolStripItem() {fileToolStripMenuItem, settingsToolStripMenuItem})
        menuStrip1.Location = New Point(0, 0)
        menuStrip1.Name = "menuStrip1"
        menuStrip1.Padding = New Padding(5, 2, 0, 2)
        menuStrip1.Size = New Size(1050, 24)
        menuStrip1.TabIndex = 1
        ' 
        ' fileToolStripMenuItem
        ' 
        fileToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {exitToolStripMenuItem})
        fileToolStripMenuItem.Name = "fileToolStripMenuItem"
        fileToolStripMenuItem.Size = New Size(37, 20)
        fileToolStripMenuItem.Text = "File"
        ' 
        ' exitToolStripMenuItem
        ' 
        exitToolStripMenuItem.Name = "exitToolStripMenuItem"
        exitToolStripMenuItem.Size = New Size(93, 22)
        exitToolStripMenuItem.Text = "Exit"
        ' 
        ' settingsToolStripMenuItem
        ' 
        settingsToolStripMenuItem.Name = "settingsToolStripMenuItem"
        settingsToolStripMenuItem.Size = New Size(61, 20)
        settingsToolStripMenuItem.Text = "Settings"
        ' 
        ' statusStrip1
        ' 
        statusStrip1.Items.AddRange(New ToolStripItem() {toolStripStatusLabel1})
        statusStrip1.Location = New Point(0, 638)
        statusStrip1.Name = "statusStrip1"
        statusStrip1.Padding = New Padding(1, 0, 12, 0)
        statusStrip1.Size = New Size(1050, 22)
        statusStrip1.TabIndex = 2
        ' 
        ' toolStripStatusLabel1
        ' 
        toolStripStatusLabel1.Name = "toolStripStatusLabel1"
        toolStripStatusLabel1.Size = New Size(39, 17)
        toolStripStatusLabel1.Text = "Ready"
        ' 
        ' openFileDialog1
        ' 
        openFileDialog1.Multiselect = True
        ' 
        ' frmMain
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1050, 660)
        Controls.Add(splitContainer1)
        Controls.Add(statusStrip1)
        Controls.Add(menuStrip1)
        MainMenuStrip = menuStrip1
        Name = "frmMain"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Project File Combiner"
        splitContainer1.Panel1.ResumeLayout(False)
        splitContainer1.Panel2.ResumeLayout(False)
        CType(splitContainer1, ComponentModel.ISupportInitialize).EndInit()
        splitContainer1.ResumeLayout(False)
        contextMenuStrip1.ResumeLayout(False)
        panel1.ResumeLayout(False)
        panel1.PerformLayout()
        menuStrip1.ResumeLayout(False)
        menuStrip1.PerformLayout()
        statusStrip1.ResumeLayout(False)
        statusStrip1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents splitContainer1 As SplitContainer
    Friend WithEvents treeView1 As TreeView
    Friend WithEvents contextMenuStrip1 As ContextMenuStrip
    Friend WithEvents selectFileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents selectFolderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents panel1 As Panel
    Friend WithEvents btnCombine As Button
    Friend WithEvents lblTokenCount As Label
    Friend WithEvents cmbProjectType As ComboBox
    Friend WithEvents lblProjectType As Label
    Friend WithEvents cmbTemplate As ComboBox
    Friend WithEvents lblTemplate As Label
    Friend WithEvents btnLoadTemplate As Button
    Friend WithEvents btnCopyTemplate As Button
    Friend WithEvents btnUpdateTemplate As Button
    Friend WithEvents btnSaveTemplate As Button
    Friend WithEvents txtTemplateName As TextBox
    Friend WithEvents lblTemplateName As Label
    Friend WithEvents txtProjectTitle As TextBox
    Friend WithEvents lblProjectTitle As Label
    Friend WithEvents txtProjectInstructions As TextBox
    Friend WithEvents lblProjectInstructions As Label
    Friend WithEvents txtOtherInstructions As TextBox
    Friend WithEvents lblOtherInstructions As Label
    Friend WithEvents menuStrip1 As MenuStrip
    Friend WithEvents fileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents exitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents settingsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents statusStrip1 As StatusStrip
    Friend WithEvents toolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents folderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents openFileDialog1 As OpenFileDialog
    Friend WithEvents btnRefresh As Button

End Class